<?php
$bot_token = "6462795099:AAEdhPSZm9o0Fe2KLx3krdePg7bGYXlvipM"; /* bot token */
$chat_id = "5044180999 "; /* chatid */
/* Telegram @fletchen */
?>